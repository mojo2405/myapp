(function($) {
  "use strict";
	

})(jQuery)